/*
 Navicat Premium Data Transfer

 Source Server         : myslq80
 Source Server Type    : MySQL
 Source Server Version : 80037
 Source Host           : localhost:3306
 Source Schema         : studentsystem

 Target Server Type    : MySQL
 Target Server Version : 80037
 File Encoding         : 65001

 Date: 28/06/2024 16:05:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for studentscore
-- ----------------------------
DROP TABLE IF EXISTS `studentscore`;
CREATE TABLE `studentscore`  (
  `studentId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '学号',
  `courseId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '课程号',
  `score` int NOT NULL COMMENT '成绩',
  PRIMARY KEY (`studentId`, `courseId`) USING BTREE,
  INDEX `courseId`(`courseId` ASC) USING BTREE,
  CONSTRAINT `courseId` FOREIGN KEY (`courseId`) REFERENCES `course` (`courseId`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `studentId` FOREIGN KEY (`studentId`) REFERENCES `studentinfo` (`studentNumber`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of studentscore
-- ----------------------------
INSERT INTO `studentscore` VALUES ('202020205501', '3', 79);
INSERT INTO `studentscore` VALUES ('202020205501', '4', 87);
INSERT INTO `studentscore` VALUES ('202020205501', '5', 89);
INSERT INTO `studentscore` VALUES ('202020205501', '6', 86);
INSERT INTO `studentscore` VALUES ('202020205501', '7', 100);
INSERT INTO `studentscore` VALUES ('202020205501', '8', 100);
INSERT INTO `studentscore` VALUES ('202020205501', 'gd01', 100);
INSERT INTO `studentscore` VALUES ('202020205501', 'ui56', 100);
INSERT INTO `studentscore` VALUES ('202020205501', 'ui78', 10);
INSERT INTO `studentscore` VALUES ('202041000101', '3', 56);
INSERT INTO `studentscore` VALUES ('202041000101', '4', 86);
INSERT INTO `studentscore` VALUES ('202041000101', '7', 56);
INSERT INTO `studentscore` VALUES ('202041000101', '8', 44);
INSERT INTO `studentscore` VALUES ('202041000101', 'gd01', 86);
INSERT INTO `studentscore` VALUES ('202041000109', '3', 89);
INSERT INTO `studentscore` VALUES ('202041000109', '4', 53);
INSERT INTO `studentscore` VALUES ('202041000109', '6', 96);
INSERT INTO `studentscore` VALUES ('202041000109', 'gd01', 66);
INSERT INTO `studentscore` VALUES ('202041000344', '3', 63);
INSERT INTO `studentscore` VALUES ('202041000344', '4', 89);
INSERT INTO `studentscore` VALUES ('202041000344', '6', 50);
INSERT INTO `studentscore` VALUES ('202041000344', '8', 60);
INSERT INTO `studentscore` VALUES ('202041000344', 'gd01', 70);
INSERT INTO `studentscore` VALUES ('202041000344', 'ui56', 80);
INSERT INTO `studentscore` VALUES ('202041000344', 'ui78', 70);
INSERT INTO `studentscore` VALUES ('202041000415', '3', 55);
INSERT INTO `studentscore` VALUES ('202041000415', '4', 88);
INSERT INTO `studentscore` VALUES ('202041000415', '6', 79);
INSERT INTO `studentscore` VALUES ('202041000415', '8', 53);
INSERT INTO `studentscore` VALUES ('202041000415', 'ui56', 37);
INSERT INTO `studentscore` VALUES ('202041000415', 'ui78', 69);
INSERT INTO `studentscore` VALUES ('202041000875', '4', 0);
INSERT INTO `studentscore` VALUES ('202041000875', '6', 0);
INSERT INTO `studentscore` VALUES ('202041000875', '8', 0);
INSERT INTO `studentscore` VALUES ('202041000875', 'gd01', 0);
INSERT INTO `studentscore` VALUES ('202041000951', '3', 80);
INSERT INTO `studentscore` VALUES ('202041000951', '4', 60);
INSERT INTO `studentscore` VALUES ('202041000951', '6', 60);
INSERT INTO `studentscore` VALUES ('202041000951', '7', 89);
INSERT INTO `studentscore` VALUES ('202041000951', '8', 66);
INSERT INTO `studentscore` VALUES ('202041001307', '3', 80);
INSERT INTO `studentscore` VALUES ('202041001307', '4', 66);
INSERT INTO `studentscore` VALUES ('202041001307', '5', 50);
INSERT INTO `studentscore` VALUES ('202041001307', '7', 78);
INSERT INTO `studentscore` VALUES ('202041001307', '8', 75);
INSERT INTO `studentscore` VALUES ('202041001307', 'gd01', 45);
INSERT INTO `studentscore` VALUES ('202041001307', 'ui56', 53);
INSERT INTO `studentscore` VALUES ('202041001307', 'ui78', 78);
INSERT INTO `studentscore` VALUES ('202041001754', '3', 66);
INSERT INTO `studentscore` VALUES ('202041001754', '6', 96);
INSERT INTO `studentscore` VALUES ('202041001754', '8', 86);
INSERT INTO `studentscore` VALUES ('202041001754', 'gd01', 78);
INSERT INTO `studentscore` VALUES ('202041001754', 'ui56', 53);
INSERT INTO `studentscore` VALUES ('202041001754', 'ui78', 58);

SET FOREIGN_KEY_CHECKS = 1;
