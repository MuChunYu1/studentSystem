/*
 Navicat Premium Data Transfer

 Source Server         : myslq80
 Source Server Type    : MySQL
 Source Server Version : 80037
 Source Host           : localhost:3306
 Source Schema         : studentsystem

 Target Server Type    : MySQL
 Target Server Version : 80037
 File Encoding         : 65001

 Date: 28/06/2024 16:04:06
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message`  (
  `messageId` int NOT NULL AUTO_INCREMENT,
  `userId` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '发布人账号',
  `userName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '发布人姓名',
  `issue` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '类型',
  `detail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '详情',
  `createTime` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `result` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '处理结果',
  `state` int NOT NULL DEFAULT 0 COMMENT '状态',
  PRIMARY KEY (`messageId`, `userId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 43 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES (26, '202020205501', '帅哥', '忘记密码', '忘记密码', '2024-06-07 11:31:27', 'p', 1);
INSERT INTO `message` VALUES (27, '202020205501', '帅哥', '忘记密码', '忘记密码', '2024-02-21 14:26:42', '', 0);
INSERT INTO `message` VALUES (29, '202020205501', '帅哥', '忘记密码', '忘记密码', '2024-06-07 11:33:49', '新密码为：112233', 1);
INSERT INTO `message` VALUES (30, '202020205501', '帅哥', '忘记密码', '忘记密码', '2024-02-28 16:30:35', '', 0);
INSERT INTO `message` VALUES (41, '202041000951', '杨招', '选课信息错误', '多选了一门课', '2024-02-28 22:20:36', '', 0);
INSERT INTO `message` VALUES (42, '202041000875', '谭慧玲', '选课信息错误', '多选了算法课', '2024-06-07 11:31:38', '', 1);

SET FOREIGN_KEY_CHECKS = 1;
