// 引入数据库
const Mysql = require('mysql')


// 连接数据库
let db = Mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'studentSystem',
  timezone: '08:00', // 解决mysql时区不一致问题
})

// 建立联系
db.connect()

function base(sql, data, callback) {
  return new Promise((resolve, reject) => {
    db.query(sql, data, (err, result) => {
      if (err) {
        return reject(new Error(`SQL语法错误,${err.message}`))
      } else{
        resolve(result)
      }
    })
  })
}

module.exports = {
  base
}


