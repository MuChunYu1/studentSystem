<template>
  <!-- <div class="cont"> -->
    <el-main><router-view></router-view></el-main>
  <!-- </div> -->
</template>

<script>
export default {
  name:'Cont'
}
</script>

<style lang="less">

</style>

